package mx.edu.utez.aweb.practica4.model.product;

public class BeanProduct {
}
